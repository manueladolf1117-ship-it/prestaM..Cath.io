﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;

class CartaParaMiAmoiii
{
    const string CONTRASENA = "365";
    static readonly Random rnd = new Random();
    static bool saltar = false;   // para acelerar la carta con cualquier tecla

    // ───────────────────────── DATOS ─────────────────────────

    static readonly ConsoleColor[] PaletaBanner =
    {
        ConsoleColor.Magenta,
        ConsoleColor.Magenta,
        ConsoleColor.Red,
        ConsoleColor.Red,
        ConsoleColor.DarkRed,
        ConsoleColor.DarkRed
    };

    static readonly string[] Banner1 =
    {
        @"██████╗  █████╗ ██████╗  █████╗     ███████╗██╗",
        @"██╔══██╗██╔══██╗██╔══██╗██╔══██╗    ██╔════╝██║",
        @"██████╔╝███████║██████╔╝███████║    █████╗  ██║",
        @"██╔═══╝ ██╔══██║██╔══██╗██╔══██║    ██╔══╝  ██║",
        @"██║     ██║  ██║██║  ██║██║  ██║    ███████╗███████╗",
        @"╚═╝     ╚═╝  ╚═╝╚═╝  ╚═╝╚═╝  ╚═╝    ╚══════╝╚══════╝"
    };

    static readonly string[] Banner2 =
    {
        @" █████╗ ███╗   ███╗ ██████╗ ██████╗     ██████╗ ███████╗",
        @"██╔══██╗████╗ ████║██╔═══██╗██╔══██╗    ██╔══██╗██╔════╝",
        @"███████║██╔████╔██║██║   ██║██████╔╝    ██║  ██║█████╗",
        @"██╔══██║██║╚██╔╝██║██║   ██║██╔══██╗    ██║  ██║██╔══╝",
        @"██║  ██║██║ ╚═╝ ██║╚██████╔╝██║  ██║    ██████╔╝███████╗",
        @"╚═╝  ╚═╝╚═╝     ╚═╝ ╚═════╝ ╚═╝  ╚═╝    ╚═════╝ ╚══════╝"
    };

    static readonly string[] Banner3 =
    {
        @"███╗   ███╗██╗    ██╗   ██╗██╗██████╗  █████╗",
        @"████╗ ████║██║    ██║   ██║██║██╔══██╗██╔══██╗",
        @"██╔████╔██║██║    ██║   ██║██║██║  ██║███████║",
        @"██║╚██╔╝██║██║    ╚██╗ ██╔╝██║██║  ██║██╔══██║",
        @"██║ ╚═╝ ██║██║     ╚████╔╝ ██║██████╔╝██║  ██║",
        @"╚═╝     ╚═╝╚═╝      ╚═══╝  ╚═╝╚═════╝ ╚═╝  ╚═╝"
    };

    static readonly string[] Carta = @"♡ ================================================== ♡

       𝓟𝓪𝓻𝓪 𝓔𝓵 𝓐𝓶𝓸𝓻 𝓓𝓮 𝓜𝓲 𝓥𝓲𝓭𝓪

                 365 días contigo

♡ ================================================== ♡


Primero, quiero pedirte perdón por copiona,
pero sí pensaba hacer esto desde el principio.


Lo primero que quiero hacer es agradecerte.
Desde siempre te he dicho que apareciste en mi vida
en el momento que más lo necesitaba. Acababa de
mudarme y, a pesar de tener personas aquí, no se
sentía bien, no se sentía como un hogar.

Eso eres para mí: un hogar donde me siento segura,
amada y comprendida.


♡ ─────────────────────────────────────────────── ♡


Sé que muchas veces no me comporto de la mejor
manera, pero créeme cuando te digo que siempre
intento ser mejor para ti.

Te mereces mi mejor versión, esa que nadie ha tenido
el privilegio de ver, solo tú, mi amor, el dueño de mi
corazón.

Haber cumplido 365 días a tu lado es un orgullo para
mí, ya que, aunque soy una persona cariñosa, nunca
había experimentado lo que era amar con tanta
intensidad como te amo a ti.


♡ ─────────────────────────────────────────────── ♡


Si me dejaras describirte en una estrofa, sería la que
va del segundo 0:19 al 0:38 de Tu Paz, de Milo J.

Solo tú puedes entenderme, solo tú sabes quién soy,
solo tú sabes cómo soy.

Sé que, si en algún momento pierdo la memoria,
tú bien podrías describir cada cosa que he vivido
sin dudarlo ni un solo segundo.


♡ ─────────────────────────────────────────────── ♡


Te amo porque eres tú.

Te amo porque me haces llorar por amarte tanto.

Te amo porque cada segundo que paso lejos de ti
se siente como una eternidad.

Te amo porque cada segundo a tu lado me regala
tiempo de vida.

Te amo porque contigo empecé a conocer la felicidad
absoluta, y no solo un momento que duraba
lo necesario.


♡ ─────────────────────────────────────────────── ♡


Lloro al momento de escribir esta carta
(como siempre) porque soy consciente de que
dependo de ti, pero es la primera vez que estoy
tan confiada al hacerlo.

Gracias por estar cuando nadie está,
gracias por entenderme cuando nadie lo hace.

Mil gracias por los mejores meses y días de mi vida.

Te amo.


♡ ================================================== ♡

Aunque mis palabras no sean largas,
mi amor es infinito.

              Te amo, Adolfo. ♥

♡ ================================================== ♡".Replace("\r\n", "\n").Split('\n');

    // ───────────────────────── PROGRAMA ─────────────────────────

    static void Main()
    {
        Console.OutputEncoding = Encoding.UTF8;
        Console.InputEncoding = Encoding.UTF8;
        Console.Title = "Para El Amor De Mi Vida";

        PantallaContrasena();

        bool primera = true;
        int opcion;
        do
        {
            opcion = MenuPrincipal(primera);
            primera = false;

            if (opcion == 1) VerCarta();
            else if (opcion == 2) AnimacionCorazon();
        }
        while (opcion != 3);

        Despedida();
    }

    // ───────────────────────── CONTRASEÑA ─────────────────────────

    static void PantallaContrasena()
    {
        Console.Clear();
        MostrarCursor(true);
        Console.WriteLine();

        Console.ForegroundColor = ConsoleColor.Red;
        Console.Write("  ");
        Maquina("❌PARA ENTRAR A ESTE PROGRAMA PRIMERO DIGITA LA CONTRASEÑA...❌", 14);
        Console.WriteLine();

        
        PedirPista();

        Console.WriteLine();
        Mensaje("Ahora siiii... ", ConsoleColor.Magenta);

        while (true)
        {
            Console.ForegroundColor = ConsoleColor.Magenta;
            Console.Write("\n  Digite la contraseña: ");
            Console.ResetColor();

            if (LeerOculto() == CONTRASENA) break;
            Mensaje("Amotitoooo, no sea bruticoooo", ConsoleColor.Red);
        }

        
        MostrarCursor(false);
        Console.Clear();
        Console.SetCursorPosition(0, Math.Max(0, Alto() / 2 - 3));
        Centrar("♥  ACCESO CONCEDIDO  ♥", ConsoleColor.Magenta);
        Console.WriteLine();
        BarraCarga("Abriendo tu corazón...", 30);
        Thread.Sleep(400);
    }

    static void PedirPista()
    {
        Console.ForegroundColor = ConsoleColor.White;
        Console.Write("\n  Necesitas una pista?: 1.SI / 2.NO  ");
        Console.ResetColor();

        while (true)
        {
            string op = (Console.ReadLine() ?? "").Trim().ToUpper();

            if (op == "1" || op == "SI" || op == "SÍ")
            {
                Mensaje("La pista inicia en 3 y termina en 65... TE AMOOOOO", ConsoleColor.Magenta);
                break;
            }
            else if (op == "2" || op == "NO")
            {
                
                Mensaje("Amotitoooo, no seas mentirosooo, la pista es los dias que tenemos juntitos", ConsoleColor.Magenta);
            }
            else
            {
                Mensaje("amiguito, es 1 o 2, si o no, te lo digo en ingles?", ConsoleColor.Red);
            }

            Console.ForegroundColor = ConsoleColor.White;
            Console.Write("\n  Necesitas una pista?: 1.SI / 2.NO  ");
            Console.ResetColor();
        }
    }

    // Lee la contraseña mostrando corazones en vez de letras
    static string LeerOculto()
    {
        var sb = new StringBuilder();
        while (true)
        {
            ConsoleKeyInfo k = Console.ReadKey(true);

            if (k.Key == ConsoleKey.Enter)
            {
                Console.WriteLine();
                break;
            }
            else if (k.Key == ConsoleKey.Backspace)
            {
                if (sb.Length > 0)
                {
                    sb.Length--;
                    Console.Write("\b \b");
                }
            }
            else if (!char.IsControl(k.KeyChar))
            {
                sb.Append(k.KeyChar);
                Console.ForegroundColor = ConsoleColor.Magenta;
                Console.Write("♥");
                Console.ResetColor();
            }
        }
        return sb.ToString().Trim();
    }

    // ───────────────────────── MENÚ ─────────────────────────

    static int MenuPrincipal(bool animado)
    {
        while (Console.KeyAvailable) Console.ReadKey(true);

        Console.Clear();
        int topBanner = 0;
        DibujarBanner(topBanner, 0, animado ? 45 : 0);

        int topMenu = topBanner + Banner1.Length + Banner2.Length + Banner3.Length + 1;
        DibujarMenu(topMenu, animado ? 60 : 0);

        EscribirCentrado(topMenu + 8, "Elige una opción (1-3)", ConsoleColor.DarkGray);

        // Mientras espera, el título brilla con un efecto de ola
        int f = 0;
        while (true)
        {
            while (!Console.KeyAvailable)
            {
                DibujarBanner(topBanner, f++, 0);
                Thread.Sleep(130);
            }

            char ch = Console.ReadKey(true).KeyChar;
            if (ch >= '1' && ch <= '3') return ch - '0';
        }
    }

    static void DibujarBanner(int top, int offset, int pausa)
    {
        DibujarBloque(Banner1, top, offset, pausa);
        DibujarBloque(Banner2, top + Banner1.Length, offset, pausa);
        DibujarBloque(Banner3, top + Banner1.Length + Banner2.Length, offset, pausa);
    }

    static void DibujarBloque(string[] bloque, int top, int offset, int pausa)
    {
        int margen = Math.Max(0, (Ancho() - bloque.Max(l => l.Length)) / 2);
        for (int i = 0; i < bloque.Length; i++)
        {
            Escribir(margen, top + i, bloque[i], PaletaBanner[(i + offset) % PaletaBanner.Length]);
            Pausa(pausa);
        }
    }

    static void DibujarMenu(int top, int pausa)
    {
        const int W = 40;
        int x = Math.Max(0, (Ancho() - (W + 2)) / 2);
        string borde = new string('═', W);
        string titulo = "♥  MENÚ PRINCIPAL  ♥";

        Escribir(x, top, "╔" + borde + "╗", ConsoleColor.Red); Pausa(pausa);
        Fila(x, top + 1, titulo.PadLeft((W + titulo.Length) / 2).PadRight(W), ConsoleColor.Magenta); Pausa(pausa);
        Escribir(x, top + 2, "╠" + borde + "╣", ConsoleColor.Red); Pausa(pausa);
        FilaOpcion(x, top + 3, "1", "Ver Carta", W); Pausa(pausa);
        FilaOpcion(x, top + 4, "2", "Ver Animación", W); Pausa(pausa);
        FilaOpcion(x, top + 5, "3", "Salir", W); Pausa(pausa);
        Escribir(x, top + 6, "╚" + borde + "╝", ConsoleColor.Red);
    }

    static void Fila(int x, int y, string contenido, ConsoleColor color)
    {
        Escribir(x, y, "║", ConsoleColor.Red);
        Console.ForegroundColor = color;
        Console.Write(contenido);
        Console.ForegroundColor = ConsoleColor.Red;
        Console.Write("║");
    }

    static void FilaOpcion(int x, int y, string num, string texto, int w)
    {
        Escribir(x, y, "║", ConsoleColor.Red);
        Console.Write(new string(' ', 6));
        Console.ForegroundColor = ConsoleColor.Magenta;
        Console.Write(num + ".");
        Console.ForegroundColor = ConsoleColor.White;
        Console.Write(("  " + texto).PadRight(w - 6 - num.Length - 1));
        Console.ForegroundColor = ConsoleColor.Red;
        Console.Write("║");
    }

    // ───────────────────────── CARTA ─────────────────────────

    static void VerCarta()
    {
        Console.Clear();
        Console.SetCursorPosition(0, Math.Max(0, Alto() / 2 - 2));
        BarraCarga("Abriendo la carta...", 24);
        Thread.Sleep(300);
        Console.Clear();

        string pad = new string(' ', Math.Max(0, (Ancho() - 56) / 2));
        saltar = false;

        Console.ForegroundColor = ConsoleColor.DarkGray;
        Console.WriteLine();
        Console.WriteLine(pad + "(presiona cualquier tecla para acelerar)");
        Console.WriteLine();

        foreach (string linea in Carta)
        {
            if (string.IsNullOrWhiteSpace(linea))
            {
                Console.WriteLine();
                if (!saltar) Thread.Sleep(80);
                continue;
            }

            Console.ForegroundColor = ColorLinea(linea);

            if (linea.TrimStart().StartsWith("♡"))
            {
                Console.WriteLine(pad + linea);
                if (!saltar) Thread.Sleep(200);
            }
            else
            {
                Console.Write(pad);
                Maquina(linea, linea.Contains("𝓟") ? 45 : 14, true);
                Console.WriteLine();
                if (!saltar) Thread.Sleep(60);
            }
        }

        Console.WriteLine();
        Console.ForegroundColor = ConsoleColor.DarkGray;
        Console.WriteLine(pad + "Presiona cualquier tecla para volver al menú...");
        Console.ResetColor();
        EsperarTecla();
    }

    static ConsoleColor ColorLinea(string linea)
    {
        string t = linea.Trim();

        if (t.StartsWith("♡")) return t.Contains("=") ? ConsoleColor.Red : ConsoleColor.Magenta;
        if (t.Contains("𝓟")) return ConsoleColor.Magenta;
        if (t.Contains("365 días contigo")) return ConsoleColor.Yellow;
        if (t.Contains("Adolfo")) return ConsoleColor.Red;
        if (t.StartsWith("Te amo")) return ConsoleColor.Magenta;
        return ConsoleColor.White;
    }

    // ───────────────────────── ANIMACIÓN DEL CORAZÓN ─────────────────────────

    static void AnimacionCorazon()
    {
        Console.Clear();
        int ancho = Ancho(), alto = Alto();

        // Tamaño del corazón según la ventana (los caracteres son ~2 veces más altos que anchos)
        int filas = Math.Min(24, alto - 7);
        filas = Math.Min(filas, (int)((ancho - 6) / 2.1));
        if (filas < 12) filas = 12;
        int cols = (int)(filas * 2.1);
        int left = Math.Max(0, (ancho - cols) / 2);
        int top = 1;

        bool[,] dentro = new bool[filas, cols];
        char[,] letra = new char[filas, cols];
        ConsoleColor[,] color = new ConsoleColor[filas, cols];
        var celdas = new List<(int r, int c)>();

        // Forma del corazón: (x² + y² − 1)³ − x²·y³ ≤ 0, rellena con "Te amo mutooo"
        string frase = "Te amo mutooo ";
        int k = 0;
        for (int r = 0; r < filas; r++)
        {
            for (int c = 0; c < cols; c++)
            {
                double y = 1.4 - r * 2.5 / (filas - 1);
                double x = -1.3 + c * 2.6 / (cols - 1);
                double a = x * x + y * y - 1;

                if (a * a * a - x * x * y * y * y <= 0)
                {
                    dentro[r, c] = true;
                    letra[r, c] = frase[k % frase.Length];
                    k++;

                    double d = Math.Sqrt(x * x + (y - 0.15) * (y - 0.15));
                    color[r, c] = d < 0.45 ? ConsoleColor.Magenta
                                : d < 0.85 ? ConsoleColor.Red
                                           : ConsoleColor.DarkRed;
                    celdas.Add((r, c));
                }
            }
        }

        // 1) El corazón se arma letra por letra, en desorden
        celdas = celdas.OrderBy(_ => rnd.Next()).ToList();
        int lote = Math.Max(1, celdas.Count / 80);
        for (int i = 0; i < celdas.Count; i += lote)
        {
            int fin = Math.Min(i + lote, celdas.Count);
            for (int j = i; j < fin; j++)
            {
                var (fr, fc) = celdas[j];
                if (letra[fr, fc] == ' ') continue;
                Escribir(left + fc, top + fr, letra[fr, fc].ToString(), color[fr, fc]);
            }
            Thread.Sleep(20);
        }

        // 2) Mensaje final
        string mensaje = "Te amo, Adolfo ♥";
        int yMsg = top + filas + 1;
        Console.SetCursorPosition(Math.Max(0, (ancho - mensaje.Length) / 2), yMsg);
        Console.ForegroundColor = ConsoleColor.Magenta;
        Maquina(mensaje, 70);
        EscribirCentrado(yMsg + 2, "Presiona cualquier tecla para volver al menú...", ConsoleColor.DarkGray);

        // 3) Latidos + corazoncitos que aparecen y desaparecen, hasta que presione una tecla
        ConsoleColor[] coloresChispa = { ConsoleColor.Red, ConsoleColor.Magenta, ConsoleColor.White, ConsoleColor.DarkMagenta };
        var chispas = new Queue<(int x, int y)>();
        int frame = 0;

        while (!Console.KeyAvailable)
        {
            int fase = frame % 16;
            if (fase == 0 || fase == 4) PintarCorazon(letra, color, left, top, true);
            else if (fase == 2 || fase == 6) PintarCorazon(letra, color, left, top, false);

            if (frame % 2 == 0)
            {
                int cx = rnd.Next(0, Math.Max(1, ancho - 2));
                int cy = rnd.Next(0, top + filas + 1);
                int rr = cy - top, cc = cx - left;
                bool ocupado = rr >= 0 && rr < filas && cc >= 0 && cc < cols && dentro[rr, cc];

                if (!ocupado)
                {
                    Escribir(cx, cy, rnd.Next(2) == 0 ? "♥" : "♡", coloresChispa[rnd.Next(coloresChispa.Length)]);
                    chispas.Enqueue((cx, cy));
                }
            }
            if (chispas.Count > 14)
            {
                var (ex, ey) = chispas.Dequeue();
                Escribir(ex, ey, " ", ConsoleColor.Black);
            }

            Thread.Sleep(90);
            frame++;
        }

        Console.ReadKey(true);
        Console.ResetColor();
    }

    static void PintarCorazon(char[,] letra, ConsoleColor[,] color, int left, int top, bool brillo)
    {
        int filas = letra.GetLength(0), cols = letra.GetLength(1);
        for (int r = 0; r < filas; r++)
        {
            for (int c = 0; c < cols; c++)
            {
                char ch = letra[r, c];
                if (ch == '\0' || ch == ' ') continue;
                Escribir(left + c, top + r, ch.ToString(), brillo ? Brillo(color[r, c]) : color[r, c]);
            }
        }
    }

    static ConsoleColor Brillo(ConsoleColor c)
    {
        switch (c)
        {
            case ConsoleColor.DarkRed: return ConsoleColor.Red;
            case ConsoleColor.Red: return ConsoleColor.Magenta;
            case ConsoleColor.Magenta: return ConsoleColor.White;
            default: return c;
        }
    }

    // ───────────────────────── DESPEDIDA ─────────────────────────

    static void Despedida()
    {
        Console.Clear();
        int y = Math.Max(0, Alto() / 2 - 2);

        CentroMaquina("Gracias por entrar, mi amor...", y, ConsoleColor.Magenta, 40);
        CentroMaquina("Te amo mutooo ♥", y + 2, ConsoleColor.Red, 60);
        Thread.Sleep(1200);

        Console.ResetColor();
        Console.SetCursorPosition(0, y + 4);
        MostrarCursor(true);
    }

    // ───────────────────────── UTILIDADES ─────────────────────────

    // Escribe letra por letra (soporta caracteres especiales como 𝓟)
    static void Maquina(string texto, int ms, bool permitirSaltar = false)
    {
        foreach (Rune r in texto.EnumerateRunes())
        {
            Console.Write(r.ToString());

            if (permitirSaltar && !saltar && Console.KeyAvailable)
            {
                Console.ReadKey(true);
                saltar = true;
            }
            if (!(permitirSaltar && saltar)) Thread.Sleep(ms);
        }
    }

    static void CentroMaquina(string texto, int y, ConsoleColor color, int ms)
    {
        Console.SetCursorPosition(Math.Max(0, (Ancho() - texto.Length) / 2), y);
        Console.ForegroundColor = color;
        Maquina(texto, ms);
    }

    static void Mensaje(string texto, ConsoleColor color)
    {
        Console.ForegroundColor = color;
        Console.Write("  ");
        Maquina(texto, 18);
        Console.WriteLine();
        Console.ResetColor();
    }

    static void BarraCarga(string texto, int total)
    {
        Centrar(texto, ConsoleColor.Magenta);
        Console.WriteLine();

        ConsoleColor[] cs = { ConsoleColor.Red, ConsoleColor.Magenta, ConsoleColor.DarkRed };
        Console.Write(new string(' ', Math.Max(0, (Ancho() - total) / 2)));
        for (int i = 0; i < total; i++)
        {
            Console.ForegroundColor = cs[i % cs.Length];
            Console.Write("♥");
            Thread.Sleep(45);
        }
        Console.WriteLine();
        Console.ResetColor();
    }

    static void Centrar(string texto, ConsoleColor color)
    {
        Console.ForegroundColor = color;
        Console.WriteLine(new string(' ', Math.Max(0, (Ancho() - texto.Length) / 2)) + texto);
        Console.ResetColor();
    }

    static void Escribir(int x, int y, string texto, ConsoleColor color)
    {
        Console.SetCursorPosition(x, y);
        Console.ForegroundColor = color;
        Console.Write(texto);
    }

    static void EscribirCentrado(int y, string texto, ConsoleColor color)
    {
        Escribir(Math.Max(0, (Ancho() - texto.Length) / 2), y, texto, color);
    }

    static void EsperarTecla()
    {
        while (Console.KeyAvailable) Console.ReadKey(true);
        Console.ReadKey(true);
    }

    static void Pausa(int ms)
    {
        if (ms > 0) Thread.Sleep(ms);
    }

    static int Ancho()
    {
        try { return Console.WindowWidth; } catch { return 120; }
    }

    static int Alto()
    {
        try { return Console.WindowHeight; } catch { return 30; }
    }

    static void MostrarCursor(bool visible)
    {
        try { Console.CursorVisible = visible; } catch { }
    }
}